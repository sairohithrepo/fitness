# 🚀 Deployment Guide for Rohith's Gym Website

## 📋 Prerequisites
- Node.js installed
- Vercel account (free at https://vercel.com)
- Git installed

## 🔧 Step 1: Install Vercel CLI
```bash
npm install -g vercel
```

## 🔐 Step 2: Login to Vercel
```bash
vercel login
```
- Choose your login method (GitHub, GitLab, or Email)
- Follow the authentication steps

## 📦 Step 3: Build the Project
```bash
npm run build
```

## 🚀 Step 4: Deploy to Vercel
```bash
vercel --prod
```
- When prompted for project name, enter: `rohith`
- Confirm the deployment settings
- Wait for deployment to complete

## 🌐 Step 5: Access Your Website
After deployment, your website will be available at:
- **Primary URL:** https://rohith.vercel.app
- **Custom URL:** You can also add a custom domain later

## 🔄 Step 6: Future Updates
To update your website after making changes:
```bash
npm run build
vercel --prod
```

## 📱 Alternative Deployment Options

### 1. Netlify
```bash
# Install Netlify CLI
npm install -g netlify-cli

# Login
netlify login

# Deploy
npm run build
netlify deploy --prod --dir=.next
```

### 2. GitHub + Vercel (Recommended)
1. Push your code to GitHub
2. Connect your GitHub account to Vercel
3. Import the project and set automatic deployments

## 🛠️ Environment Variables
Make sure to set these environment variables in your Vercel dashboard:
- `DATABASE_URL` (for production database)

## 📊 Database Setup
For production, you'll need to:
1. Set up a production database (Vercel Postgres, PlanetScale, etc.)
2. Update the `DATABASE_URL` environment variable
3. Run database migrations:
   ```bash
   npx prisma migrate deploy
   npx prisma generate
   ```

## 🎉 Your Gym Website Features
✅ Calorie tracking and meal logging
✅ Workout schedule management  
✅ Progress tracking with charts
✅ User profile management
✅ Responsive design
✅ Real-time updates

## 📞 Support
If you need help with deployment, visit:
- Vercel Documentation: https://vercel.com/docs
- Next.js Deployment Guide: https://nextjs.org/docs/deployment